#include "configdialog.h"

ConfigDialog::ConfigDialog(QWidget *parent, Qt::WindowFlags f)
{
    (void) f;
    (void) parent;
}

ConfigDialog::~ConfigDialog(){}

